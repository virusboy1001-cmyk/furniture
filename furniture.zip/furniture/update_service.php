<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Service</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);
    include "db.php";
    $id = $_GET['id'];
    $data = "SELECT * FROM services WHERE id = '$id'";
    $raw_data = $connection->query($data);
    $old_data = mysqli_fetch_array($raw_data);


    // $result = mysqli_query($connection, $data);

    // $service = mysqli_fetch_assoc($result);
    if (isset($submit)) {
        $id = $_GET['id'];
        $title = $_POST['title'];
        $description = $_POST['description'];
        $submit = $_POST['submit'];
        $icon = $_POST['icon'];
        if (!empty($_FILES['icon']['name'])) {

            $icon =$_FILES['icon']['name'];
            $tmp_name = $_FILES['icon']['tmp_name'];
            move_uploaded_file($tmp_name, "static/" . $icon);
        }

        $data = "UPDATE services SET title ='$title', icon = '$icon', description = '$description' WHERE id= '$id'";

        $connection->query($data);

        header("Location: about.php");
        exit();
    }


    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Services Update Form</h3>

            <input type="text" name="title" placeholder="Enter your service name" class="box" value="<?php echo $old_data['title']; ?>" required>
            <input type="text" placeholder="Enter your icon" name="icon" class="box" value="<?php echo $old_data['icon']; ?>" required>
            <input type="text" name="description" placeholder="Enter your description" class="box" value="<?php echo $old_data['description']; ?>">
            <button type="submit" name="submit" class="btn" value="<?php echo $old_data['submit']; ?>">Update Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>