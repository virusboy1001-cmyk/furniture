<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>

    <?php

    include('components/connection.php');

    $id = $_GET['id'];

    $sql = "DELETE FROM categories WHERE id = $id";

    $connection->query($sql);

    header("Location: shop.php");
    exit();

    ?>
    <main class="container">
        <form method="POST">
            <div>
                <div>
                    <h3>Are you sure to want to delete this post?</h3>
                </div>
                <div>
                    <button name="submit" type="submit" class="btn btn-danger">Yes</button>
                    <a href="shop.php" class="btn btn-success">No</a>
                </div>
            </div>
        </form>
    </main>
    <?php include 'components/footer.php' ?>

</body>

</html>