<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>

</head>

<body>

    <?php
    include('components/connection.php');
    $categories_sql = "SELECT * FROM categories ORDER BY id DESC";
    $categories_result = $connection->query($categories_sql);

    $products_sql = "SELECT * FROM products ORDER BY id DESC";
    $products_result = $connection->query($products_sql);
    ?>

    <?php include('components/header.php'); ?>

    <?php include('components/navbar.php'); ?>

    <!-- heading section start -->

    <section class="heading">
        <h3>our shop</h3>
        <p><a href="index.php">home</a> / <span>shop</span></p>
    </section>

    <!-- heading section end -->

    <!-- category section start -->

    <section class="category">
        <h1 class="title"> <span>our categories</span> <a href="create_category.php" class="btn title-btn">Add new category</a> </h1>

        <div class="box-container">

            <?php while ($row = $categories_result->fetch_assoc()) { ?>

                <div class="category_title">

                    <img src="<?php echo $row['icon']; ?>" alt="">

                    <h3><?php echo $row['name']; ?></h3>

                    <div class="icon">

                        <a href="update_category.php?id=<?php echo $row['id']; ?>">
                            <i class="ri-edit-line"></i>
                        </a>

                        <a href="delete_category.php?id=<?php echo $row['id']; ?>">
                            <i class="ri-delete-bin-line"></i>
                        </a>
                    </div>
                </div>
            <?php } ?>
    </section>

    <!-- category section end -->


    <!-- products section start -->

    <section class="products">
        <h1 class="title"> <span>our products</span> <button onclick="window.location.href='create_product.php'" class="btn title-btn">Add new product</button></h1>

        <div class="box-container">
            <?php while ($product = $products_result->fetch_assoc()) { ?>

                <div class="box">
                    <div class="icons">
                        <a href="update_product.php?id=<?php echo $product['id']; ?>">
                            <i class="ri-pencil-line"></i>
                        </a>

                        <a href="delete_product.php?id=<?php echo $product['id']; ?>"
                            onclick="return confirm('Are you sure you want to delete this product?');">
                            <i class="ri-delete-bin-line"></i>
                        </a>
                    </div>
                    <div class="image">
                        <img src="static/<?php echo $product['image']; ?>" alt="">
                        <p>Current Image : <?php echo $product['image']; ?></p>
                    </div>
                    <div class="content">
                        <p> $ <?php echo $product['price']; ?></p>

                        <h3><?php echo $product['title']; ?></h3>

                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <span> (50) </span>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- products section end -->

    <?php include('components/footer.php'); ?>

    <?php include('components/js.php'); ?>

</body>

</html>