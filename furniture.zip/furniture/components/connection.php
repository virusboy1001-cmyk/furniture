<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "finaldb";

$connection = new mysqli(
    $servername,
    $username,
    $password,
    $database);