<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Create</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');

    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];

        $image = $_FILES['image']['name'];
        $tmp_name = $_FILES['image']['tmp_name'];
        $upload_folder = "static/uploads";
        move_uploaded_file($tmp_name, $upload_folder . $image);

        $data = "INSERT INTO products (title, price, image, quantity) VALUES ('$title', '$price', '$image', '$quantity')";

        $connection->query($data);

        header("Location: shop.php");
        exit();
    }

    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Product Create Form</h3>

            <input type="text" name="title" placeholder="Enter your product name" class="box" required>
            <input type="number" placeholder="Enter your price" name="price" class="box" required>
            <input type="number" placeholder="Enter your quantity" name="quantity" class="box" required>
            <input type="file" name="image" accept="image/*" class="box" required>
            <button type="submit" name="submit" class="btn">Create Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>