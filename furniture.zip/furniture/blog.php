<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>

    <?php
    // session_start();

    // if (!isset($_SESSION['username'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    ?>

    <?php include('components/connection.php');
    $blogs_sql = "SELECT * FROM blogs ORDER BY id DESC";
    $blogs_result = $connection->query($blogs_sql);
    ?>


    <?php include('components/header.php'); ?>


    <?php include('components/navbar.php'); ?>

    <!-- heading section start -->

    <section class="heading">
        <h3>our shop</h3>
        <p><a href="index.php">home</a> / <span>blog</span></p>
    </section>

    <!-- heading section end -->

    <!-- blog section start -->

    <section class="blog">
        <h1 class="title"> <span>our blogs</span> <button onclick="window.location.href='create_blog.php'" class="btn title-btn">Add new blog</button></h1>

        <div class="box-container">
            <?php while ($blog = $blogs_result->fetch_assoc()) { ?>

                <div class="box">
                    <div class="image">
                        <img src="static/<?php echo $blog['image']; ?>" alt="">
                    </div>
                    <div class="content">
                        <h3><?php echo $blog['title']; ?></h3>
                        <p><?php echo $blog['description']; ?></p>

                        <div class="icon">
                            <a href="update_blog.php?id=<?php echo $blog['id']; ?>">
                                <i class="ri-pencil-line"></i>
                            </a>

                            <a href="delete_blog.php?id=<?php echo $blog['id']; ?>"
                                onclick="return confirm('Are you sure you want to delete this product?');">
                                <i class="ri-delete-bin-line"></i>
                            </a>
                        </div>
                        <div class="icons">
                            <a href="#"> <i class="fas fa-calendar"></i> 21st may, 2023</a>
                            <a href="#"> <i class="fas fa-user"></i> by admin</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- blog section end -->



    <?php include('components/footer.php'); ?>

    <?php include('components/js.php'); ?>

</body>

</html>