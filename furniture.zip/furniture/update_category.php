<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update_category</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>

</head>

<body>
    <?php

    include('components/connection.php');

    $id = $_GET['id'];

    $sql = "SELECT * FROM categories WHERE id = $id";
    $result = $connection->query($sql);
    $row = $result->fetch_assoc();

    if (isset($_POST['submit'])) {

        $name = $_POST['name'];
        $icon = $_POST['icon'];

        $sql = "UPDATE categories SET name='$name', icon='$icon' WHERE id=$id";

        $connection->query($sql);

        header("Location: shop.php");
        exit();
    }

    ?>


    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Category Create Form</h3>

            <div class="category_name">
                <label>Category Name</label>
                <input type="text" name="name" placeholder="Enter category name" class="box" value="<?php echo $row['name']; ?>" required><br><br>
            </div>

            <div class="category_icon">
                <label>Icon</label>
                <input type="text" name="icon" class="box" placeholder="choose your icon" value="<?php echo $row['icon']; ?>" required><br><br>
            </div>
            <div class="submit">
                <button type="submit" name="submit" class="btn">Update Category</button>
            </div>

        </form>
    </div>
    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>


</body>

</html>