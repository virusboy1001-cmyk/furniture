<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Team</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);
    $id = $_GET['id'];
    $sql = "SELECT * FROM teams WHERE id = $id";
    $result = $connection->query($sql);
    $team = $result->fetch_assoc();
    if (isset($submit)) {

        $name = $_POST['name'];
        $position = $_POST['position'];
        $profile = $_POST['profile'];
        $submit = $_POST['submit'];

        $profile = $_FILES['profile']['name'];
        $tmp_profile = $_FILES['profile']['tmp_profile'];
        $upload_folder = "static/uploads";
        move_uploaded_file($tmp_profile, "static/" . $profile);


        $data = "UPDATE teams SET name='$name', position='$position', profile='$profile' WHERE id= '$id'";

        $connection->query($data);

        header("Location: team.php");
        exit();
    }
    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Team Update Form</h3>

            <input type="text" name="name" placeholder="Enter your name" class="box" value="<?php echo $team['name']; ?>" required>
            <input type="text" placeholder="Enter your position" name="position" class="box" value="<?php echo $team['position']; ?>" required>
            <input type="text" name="profile" accept="image/*" class="box" value="<?php echo $team['profile']; ?>" required>
            <button type="submit" name="submit" class="btn" value="<?php echo $team['submit']; ?>">Update Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>