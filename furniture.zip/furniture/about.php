<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>

</head>

<body>
    <?php
    // session_start();

    // if (!isset($_SESSION['username'])) {
    //     header('Location: login.php');
    //     exit();
    // }
    ?>

    <?php include('components/connection.php');
    $services_sql = "SELECT * FROM services ORDER BY id DESC";
    $services_result = $connection->query($services_sql);
    ?>


    <?php include('components/header.php'); ?>

    <?php include('components/navbar.php'); ?>

    <!-- heading section start -->

    <section class="heading">
        <h3>our shop</h3>
        <p><a href="index.php">home</a> / <span>about</span></p>
    </section>

    <!-- heading section end -->



    <!-- about section start -->

    <section class="about">

        <div class="image">
            <img src="static/about-img.jpg" alt="">
        </div>

        <div class="content">
            <span>welcome to our shop</span>
            <h3>we make your home more astonishing</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid fugit labore facere non autem soluta tempora natus, sequi obcaecati esse officia aspernatur impedit dignissimos ut porro praesentium similique numquam magnam.</p>
            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Numquam sequi illo cum expedita, eius laboriosam? Blanditiis quisquam, iure nisi, ex amet odit obcaecati eaque voluptatibus porro repudiandae sit libero debitis!</p>
            <a href="#" class="btn">read more</a>
        </div>

    </section>

    <!-- about section end -->


    <!-- services section start -->

    <section class="services">

        <h1 class="title"> <span>our services</span> <button onclick="window.location.href='service.php'" class="btn title-btn">Add new service</button></h1>

        <div class="box-container">
            <?php while ($service = $services_result->fetch_assoc()) { ?>

                <div class="box">
                    <img src="static/<?php echo $service['icon']; ?>" alt="">

                    <h3><?php echo $service['title']; ?></h3>

                    <p><?php echo $service['description']; ?></p>
                    <div class="icon">
                        <a href="update_service.php?id=<?php echo $service['id']; ?>">
                            <i class="ri-pencil-line"></i>
                        </a>

                        <a href="delete_service.php?id=<?php echo $service['id']; ?>"
                            onclick="return confirm('Are you sure you want to delete this product?');">
                            <i class="ri-delete-bin-line"></i>
                        </a>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- services section end -->


    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>