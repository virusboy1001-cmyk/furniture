<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Team</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);

    $name = $_POST['name'];
    $position = $_POST['position'];
    $submit = $_POST['submit'];
    $profile = $_FILES['profile']['name'];
    $tmp_name = $_FILES['profile']['tmp_name'];
    $upload_folder = "static/uploads";
    move_uploaded_file($tmp_name, $upload_folder . $profile);

    if (isset($submit)) {

        $data = "INSERT INTO teams (name, position, profile) VALUES ('$name', '$position', '$profile')";

        $connection->query($data);

        header("Location: team.php");
        exit();
    }


    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Team Create Form</h3>

            <input type="text" name="name" placeholder="Enter your name" class="box" required>
            <input type="text" placeholder="Enter your position" name="position" class="box" required>
            <input type="file" name="profile" accept="image/*" class="box" required>
            <button type="submit" name="submit" class="btn">Create Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>