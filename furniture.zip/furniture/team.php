<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>

    <?php
    include('components/connection.php');
    error_reporting(1);
    include "db.php";
    $teams_sql = "SELECT * FROM teams ORDER BY id DESC";
    $teams_result = $connection->query($teams_sql);

    $name = $_POST['name'];
    $position = $_POST['position'];
    $profile = $_POST['profile'];
    $submit = $_POST['submit'];
    if (isset($submit)) {
        $data = "INSERT INTO teams (name, position, profile) VALUES ('$name', '$position', '$profile')";

        $connection->query($data);

        header("Location: team.php");
        exit();
    }

    ?>

    <?php include('components/header.php'); ?>


    <?php include('components/navbar.php'); ?>



    <!-- heading section start -->

    <section class="heading">
        <h3>our shop</h3>
        <p><a href="index.php">home</a> / <span>team</span></p>
    </section>

    <!-- heading section end -->

    <!-- team section start -->

    <section class="team">

        <h1 class="title"> <span>Our Teams</span> <a href="create_team.php" class="btn title-btn">Add new Team Member</a> </h1>

        <div class="box-container">
            <?php while ($team = $teams_result->fetch_assoc()) { ?>

                <div class="box">
                    <div class="share">

                        <a href="update_team.php?id=<?php echo $team['id']; ?>">
                            <i class="ri-pencil-line"></i>
                        </a>

                        <a href="delete_team.php?id=<?php echo $team['id']; ?>"
                            onclick="return confirm('Are you sure you want to delete this product?');">
                            <i class="ri-delete-bin-line"></i>
                        </a>
                    </div>
                    
                    <div class="image">
                        <img src="static/<?php echo $team['profile']; ?>" alt="">
                    </div>
                    <div class="user">
                        <h3><?php echo $team['name']; ?></h3>
                        <span><?php echo $team['position']; ?></span>
                    </div>
                </div>
            <?php } ?>
        </div>
    </section>

    <!-- team section end -->







    <?php include('components/footer.php'); ?>

    <?php include('components/js.php'); ?>

</body>

</html>