<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product</title>
</head>

<body>
    <?php

    include('components/connection.php');

    $id = $_GET['id'];

    $data = "DELETE FROM products WHERE id = '$id'";

    $connection->query($data);

    header("Location: shop.php");
    exit();

    ?>
    <main class="container">
        <form method="POST">
            <div>
                <div>
                    <h3>Are you sure to want to delete this post?</h3>
                </div>
                <div>
                    <button name="submit" type="submit" class="btn btn-danger">Yes</button>
                    <a href="shop.php" class="btn btn-success">No</a>
                </div>
            </div>
        </form>
    </main>
    <?php include 'components/footer.php' ?>


</body>

</html>