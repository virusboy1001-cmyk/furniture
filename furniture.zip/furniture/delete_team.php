<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Team</title>
</head>

<body>
    <?php

    include('components/connection.php');

    $id = $_GET['id'];

    $data = "DELETE FROM teams WHERE id = '$id'";

    $connection->query($data);

    header("Location: team.php");
    exit();

    ?>
    <main class="container">
        <form method="POST">
            <div>
                <div>
                    <h3>Are you sure to want to delete this post?</h3>
                </div>
                <div>
                    <button name="submit" type="submit" class="btn btn-danger">Yes</button>
                    <a href="team.php" class="btn btn-success">No</a>
                </div>
            </div>
        </form>
    </main>
    <?php include 'components/footer.php' ?>


</body>

</html>