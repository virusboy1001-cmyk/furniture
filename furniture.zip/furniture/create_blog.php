<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Blog</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $author = $_POST['author'];
    $submit = $_POST['submit'];
    $image = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];
    $upload_folder = "static/uploads";
    move_uploaded_file($tmp_name, $upload_folder . $image);

    if (isset($submit)) {

        $data = "INSERT INTO blogs (title, image, description, author) VALUES ('$title', '$image', '$description', '$author')";

        $connection->query($data);

        header("Location: blog.php");
        exit();
    }
    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Blog Create Form</h3>

            <input type="text" name="title" placeholder="Enter your blog title" class="box" required>
            <input type="file" name="image" accept="image/*" class="box" required>
            <input type="text" placeholder="Enter your description" name="description" class="box" required>
            <input type="text" placeholder="Enter your author" name="author" class="box" required>
            <button type="submit" name="submit" class="btn">Create Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>