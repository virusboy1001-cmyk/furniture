<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update_blog</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>

</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);
    include "db.php";
    $id = $_GET['id'];
    $data = "SELECT * FROM blogs WHERE id = '$id'";
    $result = mysqli_query($connection, $data);
    $blog = mysqli_fetch_assoc($result);

    if (isset($_POST['submit'])) {

        $id = $_POST['id'];
        $title = $_POST['title'];
        $image = $_POST['image'];
        $description = $_POST['description'];
        $author = $_POST['author'];
        $submit = $_POST['submit'];

        $sql = "UPDATE blogs SET title='$title', image='$image', description='$description', author='$author' WHERE id= '$id'";

        $connection->query($sql);

        header("Location: blog.php");
        exit();
    }
    ?>


    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Blog Update Form</h3>

            <input type="text" name="title" placeholder="Enter your blog title" class="box" value="<?php echo $blog['title']; ?>" required>
            <input type="text" name="image" accept="image/*" class="box" value="<?php echo $blog['image']; ?>" required>
            <input type="text" placeholder="Enter your description" name="description" class="box" value="<?php echo $blog['description']; ?>" required>
            <input type="text" placeholder="Enter your author" name="author" class="box" value="<?php echo $blog['author']; ?>" required>
            <button type="submit" name="submit" class="btn">Update Now</button>
        </form>
    </div>
    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>


</body>

</html>