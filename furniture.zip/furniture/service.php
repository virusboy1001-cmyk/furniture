<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);

    $title = $_POST['title'];
    $icon = $_POST['icon'];
    $description = $_POST['description'];
    $submit = $_POST['submit'];

    if (isset($submit)) {

        $data = "INSERT INTO services (title, icon, description) VALUES ('$title', '$icon', '$description')";

        $connection->query($data);

        header("Location: about.php");
        exit();
    }
    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Services Create Form</h3>

            <input type="text" name="title" placeholder="Enter your service name" class="box" required>
            <input type="file" placeholder="Enter your icon" name="icon" class="box" required>
            <textarea name="description" placeholder="Enter your description" class="box"></textarea>
            <button type="submit" name="submit" class="btn">Create Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>