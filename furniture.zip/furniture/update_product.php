<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Update</title>
    <link rel="icon" href="static/favicon.ico">
    <?php include('components/css.php'); ?>
</head>

<body>
    <?php

    include('components/connection.php');
    error_reporting(1);
    include "db.php";
    $id = $_GET['id'];
    $data = "SELECT * FROM products WHERE id = '$id'";

    $result = $connection->query($data);
    $product = $result->fetch_assoc();

    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $price = $_POST['price'];
        $quantity = $_POST['quantity'];
        if (!empty($_FILES['image']['name'])) {

            $image = $_FILES['image']['name'];
            $tmp_name = $_FILES['image']['tmp_name'];

            move_uploaded_file($tmp_name, "static/" . $image);

            $data = "UPDATE products SET title='$title', price='$price', 'image=$image', quantity='$quantity'  WHERE id = '$id'";
        }

        $connection->query($data);

        header("Location: shop.php");
        exit();
    }
    ?>

    <?php include('components/header.php'); ?>
    <?php include('components/navbar.php'); ?>

    <!-- register form start  -->

    <div class="register-form">
        <form method="POST" enctype="multipart/form-data" action="">
            <h3>Product Update Form</h3>

            <input type="text" name="title" placeholder="Enter your product name" class="box" value="<?php echo $product['title']; ?>" required>
            <input type="number" placeholder="Enter your price" name="price" class="box" value="<?php echo $product['price']; ?>" required>
            <input type="number" placeholder="Enter your quantity" name="quantity" class="box" value="<?php echo $product['quantity']; ?>" required>
            <input type="text" name="image" accept="image/*" class="box" value="<?php echo $product['image']; ?>" required>
            <button type="submit" name="submit" class="btn">Update Now</button>
        </form>
    </div>

    <!-- register form end  -->

    <?php include('components/footer.php'); ?>
    <?php include('components/js.php'); ?>

</body>

</html>