-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 05, 2026 at 04:45 PM
-- Server version: 8.4.7
-- PHP Version: 8.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `finaldb`
--

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created-at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `title`, `image`, `description`, `author`, `created-at`) VALUES
(5, 'blog', 'blog-1.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed minus, iusto quasi laboriosam                             voluptatibus at esse maxime quod quae mollitia molestiae magnam aperiam aspernatur eius                             obcaecati enim eveniet quis fugit!', 'ATHN', '2026-10-05 14:57:39'),
(6, 'blog', 'blog-2.jpg', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Sed minus, iusto quasi laboriosam                             voluptatibus at esse maxime quod quae mollitia molestiae magnam aperiam aspernatur eius                             obcaecati enim eveniet quis fugit!', 'ATHN', '2026-10-05 14:59:18');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `icon`, `created_at`) VALUES
(17, 'corner Table', 'static/icon-3.png', '2026-09-20 12:58:02'),
(16, 'working Table', 'static/icon-2.png', '2026-09-20 12:57:35'),
(14, 'house sofa', 'static/icon-1.png', '2026-09-20 11:14:58');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `phone`, `email`, `message`, `created at`) VALUES
('aung thiha naing', 2147483647, 'aungthihanaing1998@gmail.com', 'Youdsd jenehe;];lfefr Message', '2026-10-05 12:54:25'),
('aung thiha naing', 2147483647, 'aungthihanaing1998@gmail.com', '', '2026-10-05 13:16:25'),
('aung thiha naing', 2147483647, 'aungthihanaing1998@gmail.com', 'tjt4jtb4t4iutb4t4i', '2026-10-05 13:17:28');

-- --------------------------------------------------------

--
-- Table structure for table `newsletters`
--

DROP TABLE IF EXISTS `newsletters`;
CREATE TABLE IF NOT EXISTS `newsletters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `newsletters`
--

INSERT INTO `newsletters` (`id`, `email`, `created at`) VALUES
(1, 'aungthihanaing1998@gmail.com', '2026-10-05 13:29:42'),
(2, 'aungthihanaing1998@gmail.com', '2026-10-05 13:29:46'),
(3, '', '2026-10-05 13:52:34'),
(4, '', '2026-10-05 15:27:05'),
(5, '', '2026-10-05 15:27:30'),
(6, '', '2026-10-05 15:41:37'),
(7, '', '2026-10-05 15:41:39'),
(8, '', '2026-10-05 15:41:46'),
(9, '', '2026-10-05 15:41:48'),
(10, '', '2026-10-05 15:42:41'),
(11, '', '2026-10-05 15:43:30'),
(12, '', '2026-10-05 15:43:34'),
(13, '', '2026-10-05 15:43:34'),
(14, '', '2026-10-05 15:43:35'),
(15, '', '2026-10-05 15:43:41'),
(16, '', '2026-10-05 15:43:57'),
(17, '', '2026-10-05 15:43:59'),
(18, '', '2026-10-05 15:44:05'),
(19, '', '2026-10-05 15:46:51'),
(20, '', '2026-10-05 15:46:52'),
(21, '', '2026-10-05 15:46:58'),
(22, '', '2026-10-05 15:47:04'),
(23, '', '2026-10-05 15:49:30'),
(24, '', '2026-10-05 15:53:50'),
(25, '', '2026-10-05 15:53:51'),
(26, '', '2026-10-05 15:54:03');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `created at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `image`, `quantity`, `created at`) VALUES
(1, 'modern', 100, 'product-1.png', 10, '2026-10-01 14:40:55'),
(3, 'modern furniture', 110, 'product-2.png', 2, '2026-10-03 13:04:54'),
(6, 'modern furniture', 140, 'product-3.png', 10, '2026-10-04 13:17:22'),
(7, 'modern furniture', 140, 'product-4.png', 2, '2026-10-04 13:21:17');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `icon`, `description`, `created at`) VALUES
(6, '24 / 7 support', 'serv-3.png', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus id necessitatibus atque quod dicta. Esse perferendis sit vel quam deleniti voluptate. Provident molestias quibusdam recusandae quas illum ratione natus hic.', '2026-10-03 18:12:22'),
(4, 'Product Selling', 'serv-1.png', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus id necessitatibus atque quod dicta. Esse perferendis sit vel quam deleniti voluptate. Provident molestias quibusdam recusandae quas illum ratione natus hic.', '2026-10-03 15:34:40'),
(5, 'Product Designing', 'serv-2.png', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Possimus id necessitatibus atque quod dicta. Esse perferendis sit vel quam deleniti voluptate. Provident molestias quibusdam recusandae quas illum ratione natus hic.', '2026-10-03 18:11:12');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
CREATE TABLE IF NOT EXISTS `teams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `position`, `profile`, `created at`) VALUES
(8, 'John Deo', 'Designer', 'team-2.jpg', '2026-10-05 15:02:01'),
(7, 'John Deo', 'Designer', 'team-1.jpg', '2026-10-05 15:01:47'),
(9, 'John Deo', 'Designer', 'team-3.jpg', '2026-10-05 15:02:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$oQpoT0/5bINF2ZcMfaPZYemtfP6C1yQo21Vfkp1ToQIV7Zq7fEzee'),
(2, 'Mg Mg', 'mgmg@gmail.com', '$2y$10$u8a2jvzEW/sSqZ11H4W2Z.Wv/T9Vz2ZZLXo76PR66W/lTNA4MlA5W'),
(3, 'kyaw kyaw', 'kyawkyaw@gmail.com', '$2y$10$f9TNBZYFQ3P9Z5gqtYOr1eo2nsGjspaplFfJqkvjHG1l84vLOKxv.');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
